from utils import bigquery
from utils import pubsub
import pandas as pd

fake_customers = pd.read_excel('Hotfix2.xls', converters={'Customer_Number__c': str})

sql = """
    SELECT * 
    FROM salesforce_input.CHURN_CUSTOMER_AGG
    WHERE Customer_Number__C IN ("{}")
""".format('", "'.join(map(str, fake_customers['Customer_Number__c'].to_list())))

churn_customer_result = bigquery.query_run(sql)
lines = churn_customer_result.to_json(orient='records', lines=True)

for line in lines.splitlines():
    pubsub_result = pubsub.send_message(line)
